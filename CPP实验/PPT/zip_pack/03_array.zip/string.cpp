#include<iostream> 
using namespace std;

void main() {
    char a[] = "jinan";
    char b[] = "jinan";

    //string a = "jinan";
    //string b = "jinan";

    if (a == b) {
        cout << "true" << endl;
    }
    else {
        cout << "false" << endl;
    }

    char c[5] = "jinan";
    cout << c << endl;
}
