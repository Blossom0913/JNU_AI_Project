#include <iostream>
using namespace std;

int main()
{
	int x = 1;
	int y = 2;
	int z = 3;
	cout << (x = y) << endl;
	cout << (x == y) << endl;
	cout << ('a' == 97) << endl;
	cout << "a = " << x+++y << endl;
}

