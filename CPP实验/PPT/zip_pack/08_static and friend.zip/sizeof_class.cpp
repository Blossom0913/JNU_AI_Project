#include <iostream>
using namespace std;

class Student {
public:
	//int id;
	//static int age;

	//void fun1() {}
	//static void fun2(){}
};

//int Student::age = 18;

void main() {
	Student s;
	cout << sizeof(s) << endl;
}
