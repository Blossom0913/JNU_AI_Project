#include<iostream> 
using namespace std;

float add(float a, float b);